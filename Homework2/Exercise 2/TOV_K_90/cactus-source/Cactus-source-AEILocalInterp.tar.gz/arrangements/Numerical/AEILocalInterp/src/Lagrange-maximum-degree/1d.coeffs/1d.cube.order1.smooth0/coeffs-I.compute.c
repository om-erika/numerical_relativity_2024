      coeffs_I->coeff_0 = RATIONAL(1.0,1.0)-x;
      coeffs_I->coeff_p1 = x;
