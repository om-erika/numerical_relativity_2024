fp t4;
      t4 = RATIONAL(1.0,1.0);
      coeffs_dxx->coeff_m1 = t4;
      coeffs_dxx->coeff_0 = RATIONAL(-2.0,1.0);
      coeffs_dxx->coeff_p1 = t4;
