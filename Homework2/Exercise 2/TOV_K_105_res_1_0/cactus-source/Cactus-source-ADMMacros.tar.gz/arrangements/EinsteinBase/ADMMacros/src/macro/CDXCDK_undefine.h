/*@@
  @header   CDXCDK_undefine.h
  @date     Aug 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef CDXCDK_GUTS

#include "DXDK_undefine.h"
#include "CHR2_undefine.h"
