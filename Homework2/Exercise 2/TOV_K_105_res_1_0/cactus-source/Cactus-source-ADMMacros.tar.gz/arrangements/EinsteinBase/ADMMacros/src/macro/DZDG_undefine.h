/*@@
  @header   DZDG_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DZDG_GUTS

#include "DZDCG_undefine.h"

