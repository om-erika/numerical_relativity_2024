/*@@
  @header   GAMMA_undefine.h
  @date     Oct 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef GAMMA_GUTS

#include "CHR2_undefine.h"
#include "UPPERMET_undefine.h"

