#ifndef BACKTRACE_HH
#define BACKTRACE_HH

namespace CarpetLib {

void request_backtraces();

} // namespace CarpetLib

#endif // #ifndef BACKTRACE_HH
